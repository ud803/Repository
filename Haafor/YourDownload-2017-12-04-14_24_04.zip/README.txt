Your ZIP file YourDownload-2017-12-04-14_24_04.zip contains the following files:

	* Haafor Challenge v20170629.pdf
	* hfc_20170614_comp.csv
	* hfc_20170614_example.csv
